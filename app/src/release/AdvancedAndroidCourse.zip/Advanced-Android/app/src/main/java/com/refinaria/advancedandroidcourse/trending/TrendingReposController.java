package com.refinaria.advancedandroidcourse.trending;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import com.refinaria.advancedandroidcourse.base.BaseController;

public class TrendingReposController extends BaseController {

    @Override
    protected int layoutRes() {
        return 0;
    }
}
